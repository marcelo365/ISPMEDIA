import { Estacao } from "./Estacao";

export interface GrupoDeEstacoes {
    pais: string;
    estacoes: Estacao[];
}
export class RadioEstacao {
    constructor(
        public id: number | null,
        public nome: string,
        public urlStream: string,
        public pais: string
    ) { }
}

export class Artista {
    constructor(
        public id: number | null,
        public nome: string,
        public biografia: string,
        public caminhoFoto: string
    ) { }
}